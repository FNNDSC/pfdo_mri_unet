try:
    from .pfdo_mgz2image    import pfdo_mgz2image
except:
    from pfdo_mgz2image     import pfdo_mgz2image
